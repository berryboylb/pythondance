def addIntegers(x, y): 
   return  x * y;
print("Sum", addIntegers(2,4))